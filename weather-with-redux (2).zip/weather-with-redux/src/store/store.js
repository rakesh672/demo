import { createStore, applyMiddleware } from 'redux';
import ReduxPromise from 'redux-promise';
import reducers from '../reducers/index';

const store = createStore(
    reducers,
    // applyMiddleware() tells createStore() how to handle middleware
    applyMiddleware(ReduxPromise)
  )

  export default store;