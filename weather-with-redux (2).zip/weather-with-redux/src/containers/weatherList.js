import React, { Component } from 'react';
import { connect } from 'react-redux';
import GoogleMap from '../components/subcomponents/googleMap';


import Chart from '../components/subcomponents/chart';

class WeatherList extends Component {
    renderWeather = (cityData) => {
        const name = cityData.city.name;
        const temperature = cityData.list.map(weather => weather.main.temp);
        const pressure = cityData.list.map(weather => weather.main.pressure);
        const humidity = cityData.list.map(weather => weather.main.humidity);
        const {lat,lon}=cityData.city.coord;

        return (
            <tr key={name}>
                <td>
                   <GoogleMap lat={lat} lon={lon} />
                </td>
                <td>
                    <Chart data={temperature} color="red" unit="K" />
                </td>
                <td>
                    <Chart data={pressure} color="blue" unit="hPa" />
                </td>
                <td>
                    <Chart data={humidity} color="green" unit="%" />
                </td>
            </tr>
        )
    }
    render() {
        return (
            <table className="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">City</th>
                        <th scope="col">Temperature(K)</th>
                        <th scope="col">Pressure(hPa)</th>
                        <th scope="col">Humidity(%)</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.weather.length>0?this.props.weather.map(this.renderWeather):<tr>Enter city name to check weather...</tr>}
                </tbody>
            </table>
        )
    }
}

function mapStateToProps({ weather }) {
    return {
        weather  //weather:weather
    }
}

export default connect(mapStateToProps)(WeatherList);