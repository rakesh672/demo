import React, { Component } from 'react';
//core
import SearchBar from '../containers/SearchBar';
import Navbar from './subcomponents/NavBar';
import WeatherList from '../containers/weatherList';
import '../App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Navbar />
        <div className="container">
          <SearchBar />
          <WeatherList />
        </div>

      </div>
    );
  }
}

export default App;
