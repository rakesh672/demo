import React, { Component } from 'react';

class Navbar extends Component {
    render() {
        return (
            <nav className="navbar navbar-dark bg-dark xs-12 sm-12">
                <a className="navbar-brand" href="#">
                    <img src="/docs/4.1/assets/brand/bootstrap-solid.svg" width="30" height="30" alt="" />
                </a>
            </nav>
        )
    }
}
export default Navbar;