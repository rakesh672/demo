const express = require('express')
const fs = require('fs')
const bodyParser = require('body-parser')

const app = express()
const PORT = 5000 || process.env.PORT

// parse application/json
app.use(bodyParser.json());                        

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

var fileData = null
fs.readFile('./data/userData.json', (error, fd) => { 
    if (error) {
       console.log(error)
    } else { 
        fileData = JSON.parse(fd)
    }
})

app.get('/', (req, res) => {
    res.status(200).send(fileData)
})

app.post('')

app.listen(PORT, (error) => { 
    if (error) {
        console.log('Error while running server')
    } else { 
        console.log('Server is listening on port:', PORT)
    }
})